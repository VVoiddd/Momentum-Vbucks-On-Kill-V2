import express from "express";
const app = express.Router();
import { verifyApikey } from "../utilities/api.js";
import Profile from "../model/profiles.js";

app.get("/api/profile/accountId/:value", verifyApikey, (req, res) => {

    const { value } = req.params;

    const query = {};
    query["accountId"] = value;

    let profile = null as any;

        Profile.findOne(query, { password: 0, _id: 0 }, (err, profile) => {
            if (err) return res.status(500).json({ error: "Internal server error" });
            if (!profile) return res.status(404).json({ error: "Profile not found" });
            profile = profile;
        });


    res.status(200).json(profile);
});

app.post("/api/profile/mtx/:accountId", verifyApikey, async (req, res) => {

    const mtxMethod = req.body.operation;
    const mtxAmount = req.body.amount;

    if (isNaN(mtxAmount)) {
        return res.status(400).end();
    }

    const accountId = req.params.accountId;
    const incValue = parseInt(mtxAmount);

    let updateQuery;

    if (mtxMethod === "set") {
        updateQuery = {
            $set: {
                [`profiles.common_core.items.Currency:MtxPurchased.quantity`]: incValue
            }
        };
    } else {
        updateQuery = {
            $inc: {
                [`profiles.common_core.items.Currency:MtxPurchased.quantity`]: mtxMethod === "remove" ? -incValue : incValue
            }
        };
    }

    const result = await Profile.updateOne({ accountId }, updateQuery);

    if (result.modifiedCount === 0) {
        return res.status(400).end();
    }

    res.json({
        status: "ok",
        message: "Amount of currency successfully updated",
        newAmount: incValue,
        result: result
    })
});

export default app;

// Mock endpoint to award vbucks for kills
app.post("/api/v1/profile/:accountId/awardVbucksForKills", async (req, res) => {
    const accountId = req.params.accountId;
    const kills = req.body.kills || 0; // Number of kills in a match
    const vbucksForKills = 250 * kills; // 250 vbucks per kill

    // Logic to add vbucksForKills to the user's profile
    // ...

    res.json({ success: true, vbucksAwarded: vbucksForKills });
});

// Mock endpoint to award vbucks for a win
app.post("/api/v1/profile/:accountId/awardVbucksForWin", async (req, res) => {
    const accountId = req.params.accountId;
    const vbucksForWin = 1000; // 1000 vbucks for a win

    // Logic to add vbucksForWin to the user's profile
    // ...

    res.json({ success: true, vbucksAwarded: vbucksForWin });
});

// Endpoint to fetch a user's Vbucks balance
app.get("/api/v1/profile/:accountId/vbucks", async (req, res) => {
    const accountId = req.params.accountId;

    // Logic to fetch the user's Vbucks balance from the database
    // For now, returning a mock balance
    res.json({ success: true, vbucks: 1000 });
});

// Internal endpoint to update a user's Vbucks balance
// This should be secured and not exposed to users directly
app.post("/api/v1/profile/:accountId/updateVbucks", async (req, res) => {
    const accountId = req.params.accountId;
    const vbucksToAdd = req.body.vbucks || 0;

    // Logic to update the user's Vbucks balance in the database
    // ...

    res.json({ success: true });
});

= express.Router();
import { verifyApikey } from "../utilities/api.js";
import Profile from "../model/profiles.js";

app.get("/api/profile/accountId/:value", verifyApikey, (req, res) => {

    const { value } = req.params;

    const query = {};
    query["accountId"] = value;

    let profile = null as any;

        Profile.findOne(query, { password: 0, _id: 0 }, (err, profile) => {
            if (err) return res.status(500).json({ error: "Internal server error" });
            if (!profile) return res.status(404).json({ error: "Profile not found" });
            profile = profile;
        });


    res.status(200).json(profile);
});

app.post("/api/profile/mtx/:accountId", verifyApikey, async (req, res) => {

    const mtxMethod = req.body.operation;
    const mtxAmount = req.body.amount;

    if (isNaN(mtxAmount)) {
        return res.status(400).end();
    }

    const accountId = req.params.accountId;
    const incValue = parseInt(mtxAmount);

    let updateQuery;

    if (mtxMethod === "set") {
        updateQuery = {
            $set: {
                [`profiles.common_core.items.Currency:MtxPurchased.quantity`]: incValue
            }
        };
    } else {
        updateQuery = {
            $inc: {
                [`profiles.common_core.items.Currency:MtxPurchased.quantity`]: mtxMethod === "remove" ? -incValue : incValue
            }
        };
    }

    const result = await Profile.updateOne({ accountId }, updateQuery);

    if (result.modifiedCount === 0) {
        return res.status(400).end();
    }

    res.json({
        status: "ok",
        message: "Amount of currency successfully updated",
        newAmount: incValue,
        result: result
    })
});

export default app;

// Mock endpoint to award vbucks for kills
app.post("/api/v1/profile/:accountId/awardVbucksForKills", async (req, res) => {
    const accountId = req.params.accountId;
    const kills = req.body.kills || 0; // Number of kills in a match
    const vbucksForKills = 250 * kills; // 250 vbucks per kill

    // Logic to add vbucksForKills to the user's profile
    // ...

    res.json({ success: true, vbucksAwarded: vbucksForKills });
});

// Mock endpoint to award vbucks for a win
app.post("/api/v1/profile/:accountId/awardVbucksForWin", async (req, res) => {
    const accountId = req.params.accountId;
    const vbucksForWin = 1000; // 1000 vbucks for a win

    // Logic to add vbucksForWin to the user's profile
    // ...

    res.json({ success: true, vbucksAwarded: vbucksForWin });
});

// Endpoint to fetch a user's Vbucks balance
app.get("/api/v1/profile/:accountId/vbucks", async (req, res) => {
    const accountId = req.params.accountId;

    // Logic to fetch the user's Vbucks balance from the database
    // For now, returning a mock balance
    res.json({ success: true, vbucks: 1000 });
});

// Internal endpoint to update a user's Vbucks balance
// This should be secured and not exposed to users directly
app.post("/api/v1/profile/:accountId/updateVbucks", async (req, res) => {
    const accountId = req.params.accountId;
    const vbucksToAdd = req.body.vbucks || 0;

    // Logic to update the user's Vbucks balance in the database
    // ...

    res.json({ success: true });
});

// Endpoint to award vbucks for kills
app.post("/api/profile/awardVbucksForKills/:accountId", verifyApikey, async (req, res) => {
    const accountId = req.params.accountId;
    const kills = req.body.kills || 0; // Number of kills in a match
    const vbucksForKills = 250 * kills; // 250 vbucks per kill

    // 
    
    const updateQuery = {
        $inc: {
            [`profiles.common_core.items.Currency:Vbucks.quantity`]: vbucksForKills
        }
    };

    const result = await Profile.updateOne({ accountId }, updateQuery);
    if (result.nModified > 0) {
        res.json({ success: true, vbucksAwarded: vbucksForKills });
    } else {
        res.json({ success: false, message: "Failed to update Vbucks balance." });
    }
});

// Endpoint to award vbucks for a win
app.post("/api/profile/awardVbucksForWin/:accountId", verifyApikey, async (req, res) => {
    const accountId = req.params.accountId;
    const vbucksForWin = 1000; // 1000 vbucks for a win

    // 
    
    const updateQuery = {
        $inc: {
            [`profiles.common_core.items.Currency:Vbucks.quantity`]: vbucksForWin
        }
    };

    const result = await Profile.updateOne({ accountId }, updateQuery);
    if (result.nModified > 0) {
        res.json({ success: true, vbucksAwarded: vbucksForWin });
    } else {
        res.json({ success: false, message: "Failed to update Vbucks balance." });
    }
});


// Endpoint to award vbucks for kills
app.post("/api/profile/awardVbucksForKills/:accountId", verifyApikey, async (req, res) => {
    const accountId = req.params.accountId;
    const kills = req.body.kills || 0; // Number of kills in a match
    const vbucksForKills = 250 * kills; // 250 vbucks per kill

    // Update the user's Vbucks balance in the database using the Profile model
    const updateQuery = { $inc: { vbucks: vbucksForKills } };
    const result = await Profile.updateOne({ accountId }, updateQuery);
    
    if (result.nModified > 0) {
        res.json({ success: true, vbucksAwarded: vbucksForKills });
    } else {
        res.json({ success: false, message: "Failed to update Vbucks balance." });
    }
});

// Endpoint to award vbucks for a win
app.post("/api/profile/awardVbucksForWin/:accountId", verifyApikey, async (req, res) => {
    const accountId = req.params.accountId;
    const vbucksForWin = 1000; // 1000 vbucks for a win

    // Update the user's Vbucks balance in the database using the Profile model
    const updateQuery = { $inc: { vbucks: vbucksForWin } };
    const result = await Profile.updateOne({ accountId }, updateQuery);

    if (result.nModified > 0) {
        res.json({ success: true, vbucksAwarded: vbucksForWin });
    } else {
        res.json({ success: false, message: "Failed to update Vbucks balance." });
    }
});
